HOEA TO WAKA - FULL LOGO PACK

Symbols: symbol artwork without text, in black and white.
Full Logos: symbol, Hoea tō Waka name, Strength in Aotearoa and both rules.
Favicons: square website icons, including a multi-size ICO.

SVG, PDF and EPS are vector files and can be resized in design software.
PNG and WebP preserve transparency. JPG has a contrasting solid background.
White artwork is intended for a dark surface; a white PDF may look blank in a white viewer.
The full-logo text is outlined, so you do not need to install the font.

Symbol image widths: 256, 512 and 1024px.
Full-logo image widths: 640, 1280 and 2560px.
Favicon sizes: 16, 32, 48, 64, 128, 180, 192 and 512px.
ICO includes 16, 32 and 48px in one file.
